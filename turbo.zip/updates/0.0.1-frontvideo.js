exports.create = {
  FrontVideo: [
    {
      'title': 'Front video',
    },
  ],
};
